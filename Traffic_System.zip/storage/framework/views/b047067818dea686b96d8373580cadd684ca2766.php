
<?php $__env->startSection('title', 'Car Information'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <?php if(Session()->has('danger')): ?>
      <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <i class="material-icons">close</i>
        </button>
        <span>
          Deleted Successfully</span>
      </div>
      <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">local_taxi</i>
                            </div>
                            <h4 class="card-title">Car Information <a href="<?php echo e(route('CarAdd')); ?>" class="btn btn-primary float-right">Add Car</a></h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="text-center">#</th>
                                            <th>Car License Number</th>
                                            <th>Car Name</th>
                                            <th>Car Model</th>
                                            <th>Car Colour</th>
                                            <th>Owner Name</th>
                                            <th>Owner Number</th>
                                            <th class="text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td class="text-center"><?php echo e($item->tagno); ?></td>
                                                <td> <?php echo e($item->carname); ?> </td>
                                                <td> <?php echo e($item->carmodel); ?> </td>
                                                <td> <?php echo e($item->carcolor); ?> </td>
                                                <td> <?php echo e($item->ownername); ?> </td>
                                                <td> <?php echo e($item->ownertelephone); ?> </td>
                                                <td class="td-actions text-right">
                                                    <a style="color: white" href="<?php echo e(route('EditRegisteredCar',Crypt::encryptString($item->id))); ?>" rel="tooltip" class="btn btn-success btn-round"
                                                        data-original-title="" title=" edit">
                                                        <i class="material-icons">edit</i>
                                                    </a>
                                                    <a style="color: white" href="<?php echo e(route('DeleteCardetails',Crypt::encryptString($item->id))); ?>" rel="tooltip" class="btn btn-danger btn-round"
                                                        data-original-title="" title=" Delete">
                                                        <i class="material-icons">close</i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Traffic_System\resources\views/car/CarRegistration.blade.php ENDPATH**/ ?>