
<?php $__env->startSection('title', 'Tax Payment'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger col-md-8 mx-auto">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
    <?php endif; ?>
            <?php if(Session()->has('Esist')): ?>
      <div class="alert alert-danger col-md-9 mx-auto">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <i class="material-icons">close</i>
        </button>
        <span>
          Already Paid</span>
      </div>
      <?php endif; ?>
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card ">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-symbols-outlined">barcode</i>
                            </div>
                            <h4 class="card-title">Pay Tax</h4>
                        </div>
                        <div class="card-body ">
                            <form method="POST" action="<?php echo e(route('Pay')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group bmd-form-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label for="tagno">Car License Number</label>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="dropdown bootstrap-select show-tick"><select class="selectpicker"
                                                    data-style="select-with-transition" title="Choose License Number" data-size="7"
                                                    tabindex="-98" name="tagno">
                                                    <option disabled="">Options</option>
                                                    <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->tagno); ?>"><?php echo e($item->tagno); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group bmd-form-group">
                                    <label class="bmd-label-floating">Driver Name</label>
                                    <input type="text" class="form-control"  name="driver_name">
                                  </div>
                                <div class="form-group bmd-form-group">
                                    <label class="bmd-label-floating">Owner Name</label>
                                    <input type="text" class="form-control" id="owner" name="owner_name" value=" " readonly>
                                  </div>
                                <div class="form-group bmd-form-group">
                                    <label class="bmd-label-floating">Amount</label>
                                    <input type="text" class="form-control"  name="amount">
                                  </div>
                                <div class="form-group bmd-form-group">
                                    <label class="bmd-label-floating">Year</label>
                                    <input type="text" class="form-control"  name="Year" readonly value="<?php echo e(date('Y')); ?>">
                                  </div>
                                  <div class="card-footer ">
                                    <button type="submit" class="btn btn-fill btn-rose">Submit</button>
                                </div>
                            </form>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<script>
    $(document).on("change","select.selectpicker",function () {
        $.post("/tax/owner/"+$(".selectpicker option:selected").val(),{'_token': '<?php echo e(csrf_token()); ?>'},function(data){
            $('#owner').val(data[0].ownername);
        })
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Traffic_System\resources\views/tax/create.blade.php ENDPATH**/ ?>