
<?php $__env->startSection('title', 'Car Accident Information'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <?php if(Session()->has('success')): ?>
      <div class="alert alert-success col-md-12 mx-auto">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <i class="material-icons">close</i>
        </button>
        <span>
          Information Deleted</span>
      </div>
      <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">car_crash</i>
                            </div>
                            <h4 class="card-title">Accident Information <a href="<?php echo e(route('acc_crt')); ?>" class="btn btn-primary float-right">Add Record</a></h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="text-center">#</th>
                                            <th>Car License Number</th>
                                            <th>Driver Name</th>
                                            <th>Accident Type</th>
                                            <th>Fines</th>
                                            <th>Jail</th>
                                            <th>Date</th>
                                            <th class="text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $accr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->tagno); ?></td>
                                                <td><?php echo e($item->D_NAME); ?></td>
                                                <td><?php echo e($item->ACC_TYPE); ?></td>
                                                <td><?php echo e($item->Fines); ?></td>
                                                <td><?php echo e($item->Jail); ?></td>
                                                <td><?php echo e($item->Date); ?></td>
                                                <td class="td-actions text-right">
                                                    <a type="button" href="<?php echo e(route('edtrcd',Crypt::encryptString($item->id))); ?>" style="color: white;" rel="tooltip"
                                                        class="btn btn-success" data-original-title="" title="Edit">
                                                        <i class="material-icons">edit</i>
                                                    </a>
                                                    <a type="button" href="<?php echo e(route('destroyRecord',Crypt::encryptString($item->id))); ?>" style="color: white;" rel="tooltip"
                                                        class="btn btn-danger" data-original-title="" title="Delete">
                                                        <i class="material-icons">close</i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Traffic_System\resources\views/accident/accident.blade.php ENDPATH**/ ?>