# Traffic Control System
raffic signal controllers are electronic devices located at intersections that control the sequence of the lights. Along with computers, communications equipment, and detectors to count and measure traffic, the controllers are frequently grouped together to control large numbers of traffic signals, either at intersections in a city or on ramps approaching expressways and motorways. While the detailed brand and type of equipment vary greatly, the functions performed by the systems are generally consistent.
# Functionality and structure of this Traffic Control System
This implementation for are electronic in junctions that control the sequence of the lights.
## Functionality of this Traffic Control System 
This system is based on the following functions.

- Login
- Register
- Dashboard
- Car Registration
- Tax Collection
- Accident Record