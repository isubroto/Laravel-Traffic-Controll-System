
<?php $__env->startSection('title', 'Tax Information'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-rose card-header-icon">
              <div class="card-icon">
                <i class="material-symbols-outlined">barcode</i>
              </div>
              <h4 class="card-title">Tax <a href="<?php echo e(route('paytax')); ?>" class="btn btn-primary float-right">Pay Tax</a></h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped text-center">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Car License Number</th>
                      <th>Car Driver Name</th>
                      <th>Owner Name</th>
                      <th>Owner Number</th>
                      <th>Paid To</th>
                      <th class="text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $tax; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($item->id); ?></td>
                      <td><?php echo e($item->tagno); ?></td>
                      <td><?php echo e($item->driver_name); ?></td>
                      <td><?php echo e($item->owner_name); ?></td>
                      <td><?php echo e($item->ownertelephone); ?></td>
                      <td><?php echo e($item->Year); ?></td>
                      <td class="text-right">$<?php echo e($item->amount); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder (2)\Traffic_System\resources\views/tax/taxinfo.blade.php ENDPATH**/ ?>